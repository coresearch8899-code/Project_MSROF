# MSROF: Multi-Surface Renewable Optimization Framework (CRRU case study)

Code for the article "Export policy, load coincidence and the deployable capacity of multi-surface solar PV on tropical university campuses: a value-based sizing framework with complementary biogas".

## Requirements
Python 3.13 or later. Install the packages with `pip install -r requirements.txt`.
Tested with NumPy 2.5, SciPy 1.18, pandas 3.0, Matplotlib 3.11 and Pillow 12.3.

## Run sequence
| Step | Command | Input | Output | Time |
|---|---|---|---|---|
| 1 | `python 00_prepare_measured_data.py <data folder>` | `Data_load/*.xls` (PEA 15-min meter), `Data_PV/CRH_merged_30min_zone_level.csv`, `Data_PV/monthly-*.csv` | `prepared/` | < 2 min |
| 2 | `python 01_landuse_maps.py <land-use map> <PV-zone map>` | campus maps (PNG/TIFF) | `outputs/landuse_raster_check.json`, `figures/fig2_maps.png` | < 1 min |
| 3 | `python 02_msrof_analysis.py` | `prepared/` | `outputs/results.json`, `sweep.csv`, `policy.csv`, `policy_sweeps.csv`, `analytic_optimum.csv`, `framework.npz`, `mc_*.npy` | about 5 min |
| 4 | `python 03_make_figures.py` | `outputs/` | `figures/*.png` (900 dpi) | < 2 min |
| 5 | `python 04_graphical_abstract.py` | `outputs/` | `figures/graphical_abstract.*` | < 1 min |

All tariff, cost, biogas and land-use inputs (Table S1 of the supplement) are embedded in the scripts.

## Reproducibility
- Monte Carlo: `numpy.random.default_rng(20261007)`, 10,000 draws (convergence in Table S14).
- Synthetic weather years: `numpy.random.default_rng(7)`, 500 years.
- Re-running steps 3 and 4 reproduces every number and figure in the article exactly.

## Data
The raw 15-minute meter data and PV monitoring logs belong to Chiang Rai Rajabhat University and the CRH installation operator and are not redistributed. They, and the `prepared/` folder derived from them, are available from the corresponding author on reasonable request, subject to the owners' permission.

## License
MIT (code). Archived on Zenodo: DOI to be added.

## Contents of this archive
- Scripts 00 to 04, `requirements.txt`, `LICENSE`.
- `outputs/`: all derived results used in the article (results.json, capacity and policy sweeps, analytic optimum, framework curves, Monte Carlo draws). `outputs/profiles.npz` and `prepared/` are not included because they contain the 15-minute campus load and PV series; they are shared with the raw data on request.
- Step 4 needs `prepared/` and `outputs/profiles.npz`; step 5 runs from the archived `outputs/` alone.
