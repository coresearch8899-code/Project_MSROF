"""
MSROF-CRRU | Script 3 of 3 | Figures
====================================
Reads prepared/ (script 0) and outputs/ (scripts 1-2) and draws all figures with matplotlib.
No titles or subtitles; multi-panel figures carry centred (a), (b), (c) labels above each panel;
all files are written at 900 dpi.  Usage: python 03_make_figures.py [Fig1_landuse_map.tiff]
"""
import sys, json, os
import numpy as np, pandas as pd
import matplotlib as mpl, matplotlib.pyplot as plt
from PIL import Image

Image.MAX_IMAGE_PIXELS = None
mpl.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "savefig.dpi": 900, "savefig.bbox": "tight"})
os.makedirs("figures", exist_ok=True)
R = json.load(open("outputs/results.json")); PS = json.load(open("prepared/prep_summary.json"))
SW = pd.read_csv("outputs/sweep.csv"); PR = np.load("outputs/profiles.npz")
FX = R["fx"]; MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
GHI_NASA = np.array([4.72, 5.16, 5.68, 5.72, 5.21, 4.75, 4.41, 4.18, 4.32, 4.51, 4.63, 4.48])
C = dict(roof="#D98E04", ground="#7A9E3B", fpv="#2E86AB", res="#1B5E7B", bg="#8E5572", grid="#B0413E", gray="#6B6B6B")
DES = ["K", "N", "A", "X", "F"]; COL = {"K": "#5BA3C7", "N": "#2E86AB", "A": "#7A9E3B", "X": "#D98E04", "F": "#B0413E", "N2": "#8E5572", "N3": "#6B6B6B"}
S = R["scenarios"]

def tag(ax, s, y=1.04):
    ax.text(0.5, y, s, transform=ax.transAxes, ha="center", va="bottom", fontsize=11, fontweight="bold")

# ---------- Fig. 2 (maps) and Fig. S1 (area shares) are drawn by script 1

# ---------- Fig. 1 MSROF framework schematic
from matplotlib.patches import FancyBboxPatch
fig, ax = plt.subplots(figsize=(13, 6.2)); ax.set_xlim(0, 13); ax.set_ylim(0, 6.2); ax.axis("off")
def box(x, y, w, h, txt, fc, fs=8.6, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.04,rounding_size=0.12", fc=fc, ec="#333333", lw=0.9))
    ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal", wrap=True)
def arr(x0, y0, x1, y1):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0), arrowprops=dict(arrowstyle="-|>", color="#333333", lw=1.2))
stages = [("1  Spatial\nresource", "Eligible surfaces $A_s$\nand tiers $s$; land-sparing\nsupply curve, $P_{max}$\n(Eqs. 1, 6, 9)"),
          ("2  Temporal\ngeneration", "Calibrated and\nvalidated output\nper kWp, $g_{s,k}$\n(Eqs. 7, 8)"),
          ("3  Load\ncoincidence", "Self-consumed $S_k$\nand exported $X_k$\nenergy per interval\n(Eq. 2)"),
          ("4  Energy\nmonetization", "TOU energy, demand\nand minimum charges;\nexport rate $\\pi_x$\n(Eqs. 3, 14)"),
          ("5  Marginal\ncapacity value", "Marginal IRR $\\rho$ and\nmarginal self-\nconsumption $\\sigma$\n(Eqs. 5, 19)"),
          ("6  Policy-dependent\noptimum", "$P^*(\\pi_x)$ and the\ndecision map in\n($R_x$, $R_d$)\n(Eqs. 4, 5)")]
xs = [0.25 + i * 2.13 for i in range(6)]
cols = ["#DCE9F2", "#E3EFD6", "#F6E7CC", "#F3DCDC", "#E6DFF0", "#D9E6E3"]
for (t, d), x, c in zip(stages, xs, cols):
    box(x, 2.45, 1.85, 1.95, "", c); ax.text(x + 0.925, 3.95, t, ha="center", va="center", fontsize=8.4, fontweight="bold")
    ax.text(x + 0.925, 3.0, d, ha="center", va="center", fontsize=7.4)
for x in xs[:-1]: arr(x + 1.88, 3.42, x + 2.11, 3.42)
inputs = ["Satellite land-use and\nPV-zoning maps", "Near-campus irradiance and\nPV monitoring (calibration\n2024, 2026; validation 2025)", "15-min utility metering\n(single campus account)",
          "Tariff schedule, Ft, minimum\ncharge; export policy", "Capital, O&M, discount\nrate, degradation", "Export remuneration\nsweep 0 to 3 THB/kWh"]
for x, t in zip(xs, inputs):
    box(x, 5.0, 1.85, 0.95, t, "#FFFFFF", fs=7.4); arr(x + 0.925, 5.0, x + 0.925, 4.32)
box(0.25, 0.35, 6.2, 1.25, "Uncertainty layer: Monte Carlo (10,000 simulations), one-at-a-time sensitivity,\nmulti-year measured yield (2023 to 2026), alternative resource scenario", "#F2F2F2", fs=8)
box(6.65, 0.35, 6.1, 1.25, "Outputs: capacity-value curve, NPV-maximizing design, break-even export rates,\nbenchmark against annual, monthly and average-day sizing; complementary biogas\nand storage evaluated within the same value test", "#F2F2F2", fs=8)
arr(3.35, 1.62, 3.35, 2.53); arr(9.7, 2.53, 9.7, 1.62)
plt.savefig("figures/fig1_framework.png"); plt.close()

# ---------- Fig. 8 generalized decision map and benchmark
FW = np.load("outputs/framework.npz"); AN = pd.read_csv("outputs/analytic_optimum.csv"); FR = R["framework"]
fig, axs = plt.subplots(1, 3, figsize=(15, 4.6), gridspec_kw={"width_ratios": [1, 1.25, 1]})
ax = axs[0]
for i, (lab, col) in enumerate(zip(["CRRU metered", "Flat (24 h)", "Office hours", "Evening peak"], [C["fpv"], C["gray"], C["roof"], C["grid"]])):
    rd, sg = FW[f"shape_{i}"]; m = rd <= 2.0
    ax.plot(rd[m], sg[m], color=col, lw=2.2 if i == 0 else 1.5, ls="-" if i == 0 else "--", label=lab)
ax.set_xlabel("$R_d$ = annual PV generation / annual demand"); ax.set_ylabel("Marginal self-consumption share $\\sigma$"); ax.set_ylim(0, 1.03); ax.set_xlim(0, 2.0)
ax.legend(fontsize=8, frameon=False, title="Load shape (same annual energy)", title_fontsize=8); tag(ax, "(a)")
ax = axs[1]; rr = FR["R_r"]
M = FW["map_m"]; ax.contourf(FW["map_rx"], FW["map_rd"], (M > 0).astype(float), levels=[-0.5, 0.5, 1.5], colors=["#F6E7CC", "#DCE9F2"], alpha=0.9)
sig = FW["sig"]; rdg = FW["rd"]
PG = np.arange(0, 40001, 250.0); YL = R["yield_land"]; LT = float(np.sum(PR["load"]))
def rdstar(rx, r):
    if rx >= 1: return np.nan
    s_ = (1 - rx) / (r - rx); idx = np.flatnonzero(sig < s_); return PG[idx[0]] * YL / LT if len(idx) else np.nan
rxs = np.linspace(0, 0.995, 200)
for r, ls, lab in ((1.15, ":", "$R_r$ = 1.15"), (rr, "-", f"$R_r$ = {rr:.2f} (CRRU)"), (1.6, "--", "$R_r$ = 1.60"), (2.0, "-.", "$R_r$ = 2.00")):
    ax.step(rxs, [rdstar(v, r) for v in rxs], where="post", color="k", ls=ls, lw=1.6 if ls == "-" else 1.1, label=lab)
sim = AN[AN.Rx < 1.0]; ax.plot(sim.Rx, sim.rd_sim, "o", ms=4, color=C["grid"], label="Full simulation optimum")
ax.axvline(1.0, color=C["gray"], lw=1); ax.axhline(4.86, color=C["gray"], lw=0.8, ls=":")
ax.text(0.03, 4.95, "technical potential of the campus ($R_d$ = 4.86)", fontsize=7, color=C["gray"], va="bottom")
ax.text(0.98, 0.08, "undersized: marginal kWp adds value", fontsize=7, ha="right"); ax.text(0.45, 2.6, "oversized:\nmarginal kWp destroys value", fontsize=7.5, ha="center")
ax.text(1.2, 2.6, "export-driven\nexpansion", fontsize=7.5, ha="center")
ax.set_xlim(0, 1.4); ax.set_ylim(0, 5.3); ax.set_xlabel("$R_x$ = export remuneration / PV generation cost"); ax.set_ylabel("$R_d$ = annual PV generation / annual demand")
ax.legend(fontsize=7, frameon=True, framealpha=0.9, loc="upper left", bbox_to_anchor=(0.0, 0.92)); tag(ax, "(b)")
ax = axs[2]; B0 = R["bench"]["0.00"]; labs = list(B0.keys()); short = ["Annual\nbalance", "Monthly\nbalance", "Average-day\nhourly", "MSROF"]
x = np.arange(4); ax.bar(x, [B0[l]["p_kwp"] / 1000 for l in labs], color=[C["grid"], C["roof"], C["ground"], C["fpv"]])
for i, l in enumerate(labs):
    ax.text(i, B0[l]["p_kwp"] / 1000 + 0.08, f"{B0[l]['loss'] / 1e6:+.2f}", ha="center", fontsize=8)
ax.set_xticks(x); ax.set_xticklabels(short, fontsize=8); ax.set_ylabel("Recommended PV capacity (MWp)"); ax.set_ylim(0, 6)
ax.text(1.5, 5.6, "labels: NPV loss against MSROF (M USD), no export remuneration", ha="center", fontsize=7.2, color=C["gray"]); tag(ax, "(c)")
plt.tight_layout(); plt.savefig("figures/fig8_decision_map.png"); plt.close()


# ---------- Fig. 2 measured campus load 2025
load = PR["load"]; cls = PR["cls"]; t = pd.to_datetime(PR["t"].astype("datetime64[m]"))
kw = load * 4
fig = plt.figure(figsize=(13, 4.4)); gs = fig.add_gridspec(1, 3, width_ratios=[1, 1.25, 1])
a0 = fig.add_subplot(gs[0]); a1 = fig.add_subplot(gs[1]); a2 = fig.add_subplot(gs[2])
s = pd.DataFrame({"e": load, "c": cls}, index=t)
mo = s.groupby([s.index.month, "c"]).e.sum().unstack(fill_value=0) / 1000
a0.bar(MON, mo[0], color=C["grid"], label="On-peak"); a0.bar(MON, mo[1], bottom=mo[0], color=C["roof"], label="Off-peak")
a0.bar(MON, mo[2], bottom=mo[0] + mo[1], color="#C9C9C9", label="Weekend / holiday")
a0.set_ylabel("Grid energy (MWh)"); a0.tick_params(axis="x", labelsize=8, rotation=90)
b = a0.twinx(); b.spines["right"].set_visible(True); b.plot(MON, np.array(R["base_dmax"]), "k-o", ms=3.5, lw=1.4, label="On-peak maximum demand")
b.set_ylabel("Maximum on-peak demand (kW)"); b.set_ylim(0, 3200)
h1, l1 = a0.get_legend_handles_labels(); h2, l2 = b.get_legend_handles_labels(); a0.legend(h1 + h2, l1 + l2, fontsize=7.5, frameon=False, loc="upper left")
tag(a0, "(a)")
hm = kw.reshape(365, 96).T
im = a1.imshow(hm, aspect="auto", cmap="viridis", origin="lower", extent=[0, 365, 0, 24])
a1.set_xlabel("Day of 2025"); a1.set_ylabel("Hour of day"); a1.set_yticks([0, 6, 12, 18, 24])
cb = plt.colorbar(im, ax=a1, pad=0.01); cb.set_label("Campus demand (kW)"); tag(a1, "(b)")
wk = np.repeat((cls.reshape(365, 96) == 0).any(axis=1), 96)          # working day = any on-peak interval
pvN = PR["pv_land"] * S["N"]["p_kwp"]
hrs = np.arange(96) / 4
for months, lab, col in (([1, 2, 12], "Cool season (Dec to Feb)", C["fpv"]), ([6, 7, 8, 9], "Rainy season (Jun to Sep)", C["grid"])):
    sel = np.isin(t.month, months)
    a2.plot(hrs, kw[sel & wk].reshape(-1, 96).mean(0), color=col, lw=2, label=f"Weekday load, {lab}")
    a2.plot(hrs, kw[sel & ~wk].reshape(-1, 96).mean(0), color=col, lw=1.2, ls="--", label=f"Weekend load, {lab}")
    a2.fill_between(hrs, 0, pvN[sel].reshape(-1, 96).mean(0), color=col, alpha=0.15)
a2.set_xlabel("Hour of day"); a2.set_ylabel("Power (kW)"); a2.set_xlim(0, 24); a2.set_ylim(0, 2700); a2.legend(fontsize=6.8, frameon=False, loc="upper left", ncol=1)
a2.text(12, 120, "mean PV output of N\n(shaded)", ha="center", fontsize=7.5, color=C["gray"]); tag(a2, "(c)")
plt.tight_layout(); plt.savefig("figures/fig3_load.png"); plt.close()

# ---------- Fig. 3 PV-model calibration (2024 + Jan-Aug 2026) and validation (2025 held out)
cal = PS["calibration"]; rc = np.load("prepared/calibration_ratios_cal.npy"); rv = np.load("prepared/calibration_ratios_val.npy")
fig, axs = plt.subplots(1, 3, figsize=(13, 4.2))
axs[0].hist(rc, bins=60, range=(0, 1.5), color=C["fpv"], alpha=0.75, density=True, label=f"Calibration 2024, 2026 (n = {len(rc):,})")
axs[0].hist(rv, bins=60, range=(0, 1.5), histtype="step", color=C["roof"], lw=1.5, density=True, label=f"Validation 2025 (n = {len(rv):,})")
axs[0].axvline(cal["eta_median"], color="k", ls="--", lw=1.3, label=f"Interval median {cal['eta_median']:.2f}")
axs[0].axvline(R["eta"], color=C["grid"], lw=1.6, label=f"Energy-matched {R['eta']:.2f}")
axs[0].axvline(0.903, color=C["gray"], ls=":", lw=1.3, label="Design loss chain 0.90")
axs[0].set_xlabel("Measured / modelled output (-)"); axs[0].set_ylabel("Probability density (G > 300 W m$^{-2}$)"); axs[0].legend(fontsize=7, frameon=False, loc="upper left"); axs[0].set_ylim(0, 3.2); tag(axs[0], "(a)")
mm = np.array(cal["zone1_2025_monthly_measured"]) / 1000; mp = np.array(cal["zone1_2025_monthly_model"]) / 1000
x = np.arange(12); axs[1].bar(x - 0.2, mm, 0.4, color=C["roof"], label="Measured 2025"); axs[1].bar(x + 0.2, mp, 0.4, color=C["fpv"], label="Model, calibrated on 2024 and 2026")
axs[1].set_xticks(x); axs[1].set_xticklabels(MON, rotation=90, fontsize=8); axs[1].set_ylabel("Monthly energy, 2,256 kWp array (MWh)"); axs[1].set_ylim(0, max(mm.max(), mp.max()) * 1.25); axs[1].legend(fontsize=7.5, frameon=False, loc="upper left"); tag(axs[1], "(b)")
g25 = np.array(PS["weather_2025"]["monthly_ghi_kwh_m2_day"])
axs[2].plot(MON, g25, "o-", color=C["roof"], lw=2, label=f"Measured 2025 ({R['ghi_2025']:.0f} kWh m$^{{-2}}$ yr$^{{-1}}$)")
axs[2].plot(MON, GHI_NASA, "s--", color=C["gray"], lw=1.6, label=f"NASA POWER 2003-2023 ({R['ghi_lt']:.0f})")
axs[2].set_ylabel("GHI (kWh m$^{-2}$ day$^{-1}$)"); axs[2].tick_params(axis="x", rotation=90, labelsize=8); axs[2].legend(fontsize=7.5, frameon=False); tag(axs[2], "(c)")
plt.tight_layout(); plt.savefig("figures/fig4_pv_calibration.png"); plt.close()

# ---------- Fig. 5 capacity-value curve
fig, axs = plt.subplots(1, 3, figsize=(14, 4.4))
tr = R["tiers"]; cum = 0
for k, c_, l in zip(["roof", "ground", "ponds", "reservoir"], [C["roof"], C["ground"], C["fpv"], C["res"]], ["Rooftop", "Ground-mounted", "Small ponds", "Reservoir"]):
    axs[0].bar(0, tr[k]["kwp"] / 1000, bottom=cum, color=c_, width=0.5)
    axs[0].text(0.32, cum + tr[k]["kwp"] / 1000 * (0.40 if k == "roof" else 0.5), f"{l}: {tr[k]['kwp'] / 1000:.2f} MWp", va="center", fontsize=8.5); cum += tr[k]["kwp"] / 1000
for k in ("N", "A"):
    axs[0].axhline(S[k]["p_kwp"] / 1000, color="k", ls="--" if k == "N" else ":", lw=1)
    axs[0].text(0.32, S[k]["p_kwp"] / 1000 + 0.35, f"Design {k} ({S[k]['p_kwp'] / 1000:.2f} MWp)", fontsize=8.5)
axs[0].set_xlim(-0.35, 1.5); axs[0].set_xticks([]); axs[0].set_ylabel("Cumulative PV capacity (MWp)"); tag(axs[0], "(a)")
sw = SW[SW.p_kwp > 0]; ax = axs[1]
ax.plot(sw.p_kwp / 1000, sw.npv / 1e6, color=C["fpv"], lw=2); ax.axhline(0, color="k", lw=0.6)
ax.set_xscale("log"); ax.set_xlabel("Installed PV capacity (MWp, log scale)"); ax.set_ylabel("25-year NPV (M USD)", color=C["fpv"])
ax2 = ax.twinx(); ax2.spines["right"].set_visible(True)
ax2.plot(sw.p_kwp / 1000, sw.marg_irr * 100, color=C["grid"], lw=1.8); ax2.axhline(7, color=C["gray"], ls=":", lw=1)
ax2.text(0.27, 7.6, "discount rate 7 %", fontsize=8, color=C["gray"]); ax2.set_ylabel("Marginal IRR of the last 250 kWp (%)", color=C["grid"]); ax2.set_ylim(-10, 16)
for k, mk in (("K", "v"), ("N", "o"), ("A", "D"), ("X", "s"), ("F", "^")):
    ax.plot(S[k]["p_kwp"] / 1000, S[k]["npv"] / 1e6, mk, color="k", ms=6.5)
    ax.annotate(k, (S[k]["p_kwp"] / 1000, S[k]["npv"] / 1e6), xytext=(4, 6), textcoords="offset points", fontsize=9, fontweight="bold")
tag(ax, "(b)")
ax = axs[2]; ax.plot(sw.p_kwp / 1000, sw.sc_share * 100, color=C["roof"], lw=2); ax.set_xscale("log")
ax.set_xlabel("Installed PV capacity (MWp, log scale)"); ax.set_ylabel("Share of generation used on campus (%)", color=C["roof"]); ax.set_ylim(0, 105)
ax3 = ax.twinx(); ax3.spines["right"].set_visible(True); ax3.plot(sw.p_kwp / 1000, sw.load_cover * 100, color=C["gray"], lw=1.8, ls="--")
ax3.set_ylabel("Share of campus grid demand displaced (%)", color=C["gray"]); ax3.set_ylim(0, 105); tag(ax, "(c)")
plt.tight_layout(); plt.savefig("figures/fig6_capacity_value.png"); plt.close()

# ---------- Fig. 4 floating ceiling
cv = pd.read_csv("outputs/fpv_ceiling.csv")
fig, (a0, a1) = plt.subplots(1, 2, figsize=(10.5, 4.3)); x = np.arange(len(cv))
a0.bar(x, cv.ponds, 0.55, color=C["fpv"], label="Small ponds"); a0.bar(x, cv.res, 0.55, bottom=cv.ponds, color=C["res"], label="Reservoir")
a0.set_xticks(x); a0.set_xticklabels([f"{int(c * 100)} %" for c in cv.ceiling]); a0.set_xlabel("Coverage ceiling (share of water surface)")
a0.set_ylabel("Floating PV capacity (MWp)"); a0.legend(frameon=False, fontsize=8.5); tag(a0, "(a)")
a1.plot(cv.ceiling * 100, cv.fpv_mwh / 1000, "o-", color=C["fpv"], lw=2); a1.set_xlabel("Coverage ceiling (%)"); a1.set_ylabel("Annual floating PV yield (GWh)")
a1.axvspan(0, 30, color="#D9EAF2", alpha=0.6); a1.axvspan(45, 60, color="#F2EAD9", alpha=0.6); ymax = cv.fpv_mwh.max() / 1000
a1.text(15, ymax * 0.92, "precautionary\nrange", ha="center", fontsize=8.5); a1.text(52.5, ymax * 0.92, "stratification\nrisk", ha="center", fontsize=8.5); tag(a1, "(b)")
plt.tight_layout(); plt.savefig("figures/fig5_fpv_ceiling.png"); plt.close()

# ---------- Fig. 6 export-remuneration policy scenarios
PO = pd.read_csv("outputs/policy.csv"); PSW = pd.read_csv("outputs/policy_sweeps.csv")
fig, axs = plt.subplots(1, 3, figsize=(14, 4.4))
ax = axs[0]; ax.step(PO.exp_thb, PO.p_opt / 1000, where="post", color=C["fpv"], lw=2.2); ax.set_yscale("log")
ax.set_xlabel("Export remuneration (THB kWh$^{-1}$)"); ax.set_ylabel("NPV-maximizing PV capacity (MWp, log scale)", color=C["fpv"])
ax.set_yticks([1, 2, 3, 5, 10, 25]); ax.yaxis.set_major_formatter(mpl.ticker.ScalarFormatter()); ax.yaxis.set_minor_formatter(mpl.ticker.NullFormatter())
axb = ax.twinx(); axb.spines["right"].set_visible(True); axb.plot(PO.exp_thb, PO.npv_opt / 1e6, color=C["grid"], lw=1.6, ls="--"); axb.set_ylabel("NPV at the optimum (M USD)", color=C["grid"])
for xv, lab in ((0.0, "no purchase\nagreement"), (1.0, "institutional\npilot (≤200 kW)"), (2.2, "residential\nscheme (≤5 kW)")):
    ax.axvline(xv, color=C["gray"], ls=":", lw=1); ax.text(xv + 0.04 if xv < 2 else xv - 0.04, 21, lab, fontsize=7, color=C["gray"], va="top", ha="left" if xv < 2 else "right")
sec = ax.secondary_xaxis("top", functions=(lambda v: v / FX, lambda v: v * FX)); sec.set_xlabel("USD kWh$^{-1}$", fontsize=8); sec.tick_params(labelsize=7)
ax.text(0.5, 1.20, "(a)", transform=ax.transAxes, ha="center", va="bottom", fontsize=11, fontweight="bold")
ax = axs[1]; ax.plot(PO.exp_thb, PO.sc_share * 100, color=C["roof"], lw=2, label="Generation used on campus")
ax.plot(PO.exp_thb, PO.ex_share * 100, color=C["res"], lw=2, ls="--", label="Generation exported"); ax.plot(PO.exp_thb, PO.cover * 100, color=C["gray"], lw=1.6, ls=":", label="Campus grid demand displaced")
ax.set_xlabel("Export remuneration (THB kWh$^{-1}$)"); ax.set_ylabel("Share at the optimum (%)"); ax.set_ylim(0, 105); ax.legend(fontsize=7.5, frameon=False, loc="center left"); tag(ax, "(b)")
ax = axs[2]
for xv, col in ((0.0, C["fpv"]), (1.0, C["ground"]), (2.2, C["roof"]), (2.6, C["grid"])):
    d = PSW[(PSW.exp_thb - xv).abs() < 1e-9]; d = d[d.p_kwp > 0]
    ax.plot(d.p_kwp / 1000, d.npv / 1e6, color=col, lw=1.8, label=f"{xv:.2f} THB kWh$^{{-1}}$")
ax.axhline(0, color="k", lw=0.6); ax.set_xlabel("Installed PV capacity (MWp)"); ax.set_ylabel("25-year NPV (M USD)"); ax.set_xlim(0, 8); ax.set_ylim(-3, 1)
ax.legend(fontsize=7.5, frameon=False, loc="lower left", title="Export remuneration", title_fontsize=7.5); tag(ax, "(c)")
plt.tight_layout(); plt.savefig("figures/fig7_export_policy.png"); plt.close()

# ---------- Fig. 8 biogas
bg = R["biogas"]
fig, (a0, a1, a2b) = plt.subplots(1, 3, figsize=(15, 4.3), gridspec_kw={"width_ratios": [1, 1.1, 1.25]})
ms = [bg["waste_t_y"], bg["waste_t_y"] * bg["ts"], bg["vs_d"] * 365 / 1000]
a0.bar(["Wet waste", "Total solids\n(35 %)", "Volatile solids\n(82 % of TS)"], ms, color=[C["bg"], "#B08968", C["roof"]])
for i, v in enumerate(ms): a0.text(i, v, f"{v:,.0f}", ha="center", va="bottom", fontsize=9)
a0.set_ylabel("Mass flow (t yr$^{-1}$)"); tag(a0, "(a)")
es = [bg["prim_kwh"] / 1000, bg["e_gross"] / 1000, bg["e_net"] / 1000, bg["h_net"] / 1000]
a1.bar(["CH$_4$ energy\ncontent", "Gross\nelectricity", "Net\nelectricity", "Net heat"], es, color=["#B08968", C["roof"], C["fpv"], C["grid"]])
for i, v in enumerate(es): a1.text(i, v, f"{v:,.0f}", ha="center", va="bottom", fontsize=9)
a1.set_ylabel("Energy (MWh yr$^{-1}$)"); tag(a1, "(b)")
bs = {k: v["be"] for k, v in R["bg_sens"].items() if "leakage" not in k}; b0 = bs.pop("Base case"); items = sorted(bs.items(), key=lambda kv: abs(kv[1] - b0))
a2b.barh(range(len(items)), [v - b0 for _, v in items], left=b0, color=[C["ground"] if v < b0 else C["grid"] for _, v in items], height=0.6)
a2b.axvline(b0, color="k", ls="--", lw=1.1); a2b.set_yticks(range(len(items))); a2b.set_yticklabels([k.replace("η_e", "η$_e$").replace("k_d", "$k_d$") for k, _ in items], fontsize=7.5)
a2b.set_xlabel("Waste credit for digester NPV = 0 (USD t$^{-1}$)"); a2b.text(b0 + 0.3, len(items) - 0.4, f"base {b0:.1f}", fontsize=7.5); tag(a2b, "(c)")
plt.tight_layout(); plt.savefig("figures/fig10_biogas.png"); plt.close()

# ---------- Fig. 9 battery
bc = pd.read_csv("outputs/batt_curve.csv")
fig, (a0, a1) = plt.subplots(1, 2, figsize=(10.5, 4.3))
a0.bar([f"N\n(no battery)", f"N + Li-ion\n({S['N2']['battery']['cap'] / 1000:.2f} MWh)", f"N + lead-acid\n({S['N3']['battery']['cap'] / 1000:.2f} MWh)"],
       [S[k]["npv"] / 1e6 for k in ("N", "N2", "N3")], color=[COL["N"], COL["N2"], COL["N3"]])
a0.axhline(0, color="k", lw=0.8); a0.set_ylabel("25-year NPV (M USD)"); tag(a0, "(a)")
a1.plot(bc.price, bc.npv, color=C["bg"], lw=2); a1.axhline(S["N"]["npv"] / 1e6, color=COL["N"], ls="--", lw=1.4); a1.axvline(14000 / FX, color=C["gray"], ls=":", lw=1.2)
a1.text(14000 / FX + 8, bc.npv.min(), "assumed price\n394 USD kWh$^{-1}$", fontsize=8, color=C["gray"], va="bottom")
a1.text(bc.price.min() + 90, S["N"]["npv"] / 1e6 + 0.004, "NPV of N without battery", fontsize=8, color=COL["N"])
a1.set_xlabel("Installed Li-ion price (USD kWh$^{-1}$)"); a1.set_ylabel("25-year NPV of N + Li-ion (M USD)"); tag(a1, "(b)")
plt.tight_layout(); plt.savefig("figures/fig11_battery.png"); plt.close()

# ---------- Fig. 7 design economics
fig, axs = plt.subplots(1, 3, figsize=(13, 4.4)); x = np.arange(5)
axs[0].bar(x, [S[k]["lcoe"] for k in DES], color=[COL[k] for k in DES]); axs[0].plot(x, [R["pv_only"][k]["lcoe"] for k in DES], "k_", ms=18, mew=2, label="PV only")
axs[0].axhline(R["base_bill"]["total"] / (sum(PR["load"])) , color="k", ls="--", lw=1.1, label="Average grid cost 0.116")
axs[0].axhline(2.20 / FX, color=C["gray"], ls=":", lw=1.2, label="Export scenario 2.20 THB (0.062)")
axs[0].axhline(1.00 / FX, color=C["gray"], ls="-.", lw=1.0, label="Export scenario 1.00 THB (0.028)")
axs[0].set_ylabel("LCOE (USD kWh$^{-1}$)"); axs[0].set_ylim(0, 0.17); axs[0].legend(fontsize=6.8, frameon=False, loc="upper center", ncol=2); tag(axs[0], "(a)")
axs[1].bar(x, [S[k]["capex"] / 1e6 for k in DES], color=[COL[k] for k in DES]); axs[1].set_yscale("log"); axs[1].set_yticks([1, 2, 5, 10, 20]); axs[1].yaxis.set_major_formatter(mpl.ticker.ScalarFormatter()); axs[1].yaxis.set_minor_formatter(mpl.ticker.NullFormatter()); axs[1].set_ylabel("CAPEX (M USD, log scale)"); tag(axs[1], "(b)")
axs[2].bar(x - 0.2, [S[k]["npv"] / 1e6 for k in DES], 0.4, color=[COL[k] for k in DES], label="PV + biogas")
axs[2].bar(x + 0.2, [R["pv_only"][k]["npv"] / 1e6 for k in DES], 0.4, color=[COL[k] for k in DES], alpha=0.45, hatch="//", label="PV only")
axs[2].axhline(0, color="k", lw=0.8); axs[2].set_yscale("symlog", linthresh=0.5); axs[2].set_yticks([-20, -10, -5, -2, -1, -0.5, 0, 0.5]); axs[2].yaxis.set_major_formatter(mpl.ticker.FuncFormatter(lambda v, p: f"{v:g}")); axs[2].yaxis.set_minor_formatter(mpl.ticker.NullFormatter()); axs[2].set_ylabel("25-year NPV (M USD, symmetric log scale)"); axs[2].legend(fontsize=8, frameon=False, loc="lower left"); tag(axs[2], "(c)")
for a in axs: a.set_xticks(x); a.set_xticklabels([f"{k}\n{S[k]['p_kwp'] / 1000:.2f} MWp" for k in DES], fontsize=8)
plt.tight_layout(); plt.savefig("figures/fig9_designs.png"); plt.close()

# ---------- Fig. 12 Monte Carlo, tornado and multi-year yield
fig, (a0, a1, a3) = plt.subplots(1, 3, figsize=(17, 4.8), gridspec_kw={"width_ratios": [1, 1.15, 0.75]})
for k, lab, col in (("K", "K, PV + biogas", COL["K"]), ("N", "N, PV + biogas", COL["N"]), ("N_pv", "N, PV only", C["roof"])):
    o = np.load(f"outputs/mc_{k}.npy")[:, 0] / 1e6
    a0.hist(o, bins=70, alpha=0.5, color=col, label=f"{lab}: P(NPV>0) = {R['mc'][k]['p_npv_pos']:.1f} %")
a0.axvline(0, color="k", lw=1); a0.set_xlim(-1.0, 1.4); a0.set_ylim(0, 680); a0.set_xlabel("25-year NPV (M USD)"); a0.set_ylabel("Frequency (10,000 simulations)"); a0.legend(fontsize=8.5, frameon=True, framealpha=0.9, loc="upper left"); tag(a0, "(a)")
tor = sorted(R["tornado"].items(), key=lambda kv: kv[1]["swing"]); base = S["N"]["npv"] / 1e6
for i, (k, v) in enumerate(tor):
    lo, hi = sorted([v["low"] / 1e6, v["high"] / 1e6]); a1.barh(i, hi - lo, left=lo, color=C["fpv"], height=0.6)
a1.axvline(base, color="k", ls="--", lw=1.2); a1.axvline(0, color=C["gray"], lw=0.8)
a1.set_yticks(range(len(tor))); a1.set_yticklabels([k for k, _ in tor], fontsize=8); a1.set_xlabel("25-year NPV of design N (M USD)"); tag(a1, "(b)")
WY = np.load("outputs/framework.npz")["wy"]
bp = a3.boxplot([WY[:, 0] / 1e6, WY[:, 1] / 1e6], widths=0.5, patch_artist=True, whis=(10, 90), showfliers=False)
for p_, c_ in zip(bp["boxes"], [COL["N"], C["roof"]]): p_.set_facecolor(c_); p_.set_alpha(0.6)
a3.plot([1, 2], [WY[0, 0] / 1e6, WY[0, 1] / 1e6], "k*", ms=9, label="actual 2024 yield")
a3.axhline(0, color="k", lw=0.7); a3.set_xticks([1, 2]); a3.set_xticklabels(["N, PV + biogas", "N, PV only"], fontsize=8)
a3.set_ylabel("25-year NPV (M USD)"); a3.legend(fontsize=7.5, frameon=False, loc="center left"); tag(a3, "(c)")
plt.tight_layout(); plt.savefig("figures/fig12_uncertainty.png"); plt.close()

# ---------- Fig. 11 co-benefits
CO = R["cobenefits"]; x = np.arange(5)
fig, (a0, a1) = plt.subplots(1, 2, figsize=(11, 4.4))
pv = np.array([CO[k]["pv_t"] for k in DES]); bgt = np.array([CO[k]["bg_t"] for k in DES]); lf = np.array([CO[k]["landfill_t"] + CO[k]["leak_t"] for k in DES])
a0.bar(x, pv, color=C["roof"], label="PV grid displacement"); a0.bar(x, bgt, bottom=pv, color=C["bg"], label="Biogas grid displacement")
a0.bar(x, lf, bottom=pv + bgt, color=C["ground"], label="Net landfill CH$_4$ avoidance"); a0.set_ylabel("GHG reduction (tCO$_2$-eq yr$^{-1}$)"); a0.legend(fontsize=8, frameon=False); tag(a0, "(a)")
ev = np.array([CO[k]["evap_m3"] for k in DES]) / 1000; dg = np.array([CO[k]["dig_m3"] for k in DES]) / 1000
a1.bar(x, ev, color=C["fpv"], label="Evaporation suppression"); a1.bar(x, dg, bottom=ev, color="#556270", label="Digestate liquid reuse")
a1.set_ylabel("Water conserved (10$^3$ m$^3$ yr$^{-1}$)"); a1.legend(fontsize=8, frameon=False); tag(a1, "(b)")
for a in (a0, a1): a.set_xticks(x); a.set_xticklabels([f"{k}\n{S[k]['p_kwp'] / 1000:.1f} MWp" for k in DES], fontsize=8)
plt.tight_layout(); plt.savefig("figures/fig13_cobenefits.png"); plt.close()

# ---------- Fig. S2 composite metrics (supplementary)
Mt = R["metrics"]
fig, axs = plt.subplots(1, 4, figsize=(14, 3.9))
for a, (k, lab, f), l in zip(axs, [("SEI", "SEI (W m$^{-2}$)", 1), ("CNED", "CNED (10$^{-5}$ kWh USD$^{-1}$ m$^{-2}$)", 1e5),
                                   ("WENI", "WENI ((MWh + 10$^3$ m$^3$) ha$^{-1}$)", 1), ("CAI", "CAI (tCO$_2$-eq ha$^{-1}$)", 1)], "abcd"):
    v = [(Mt[s][k] if (Mt[s][k] is not None and Mt[s][k] == Mt[s][k]) else 0) * f for s in DES]
    a.bar(x, v, color=[COL[s] for s in DES]); a.set_xticks(x); a.set_xticklabels(DES); a.set_ylabel(lab, fontsize=9); tag(a, f"({l})")
    for i, val in enumerate(v): a.text(i, val, "n/a" if val == 0 else f"{val:.3g}", ha="center", va="bottom", fontsize=8)
plt.tight_layout(); plt.savefig("figures/figS2_metrics.png"); plt.close()

print(sorted(os.listdir("figures")))
