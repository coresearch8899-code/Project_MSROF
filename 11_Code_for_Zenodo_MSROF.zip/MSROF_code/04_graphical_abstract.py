"""Graphical abstract for the MSROF article (Elsevier: >= 1328 x 531 px, w x h)."""
import json, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
R = json.load(open("outputs/results.json")); F = np.load("outputs/framework.npz")
D = pd.read_csv("outputs/policy_sweeps.csv")
T = R["tiers"]; RR = R["framework"]["R_r"]
fig, ax = plt.subplots(1, 3, figsize=(10.0, 4.0), gridspec_kw={"width_ratios": [1.0, 1.05, 1.25]})
# (a) surface potential vs optimum
names = ["Rooftop", "Ground", "Ponds", "Reservoir"]; keys = ["roof", "ground", "ponds", "reservoir"]
cols = ["#7b5cc4", "#c98a4b", "#7cc6e8", "#2f7fb5"]; left = 0
for n, k, c in zip(names, keys, cols):
    v = T[k]["kwp"] / 1000; ax[0].barh(0, v, left=left, color=c, height=0.5, label=f"{n} {v:.1f}")
    left += v
ax[0].barh(-0.7, 1.25, color="#d1495b", height=0.5)
ax[0].text(1.6, -0.7, "NPV optimum, no export pay:\n1.25 MWp (5%)", va="center", fontsize=8.5)
ax[0].text(left, 0.42, f"{left:.1f} MWp technical potential", ha="right", fontsize=8.5)
ax[0].set_yticks([]); ax[0].set_xlabel("PV capacity (MWp)"); ax[0].set_ylim(-1.2, 1.9); ax[0].set_xlim(0, 26.5)
ax[0].legend(loc="upper left", fontsize=7.5, frameon=False, ncol=2, title="Surfaces (MWp)", title_fontsize=8)
# (b) coincidence curve and rule
rd, sig = F["rd"], F["sig"]; m = rd <= 2.0
ax[1].plot(rd[m], sig[m], color="k", lw=1.6, label="Measured coincidence σ(R$_d$)")
for x, c in [(0.0, "#d1495b"), (1.0, "#edae49"), (2.2, "#00798c")]:
    rx = x / 35.5 / R["framework"]["c_pv"]; th = (1 - rx) / (RR - rx)
    ax[1].axhline(th, color=c, ls="--", lw=1)
    ax[1].text(1.98, th + 0.015, f"{x:.1f} THB/kWh", color=c, ha="right", fontsize=7.5)
ax[1].set_xlabel("PV generation / demand, R$_d$"); ax[1].set_ylabel("Marginal self-consumption share")
ax[1].text(0.03, 0.06, r"Optimum where $\sigma=\dfrac{1-R_x}{R_r-R_x}$", transform=ax[1].transAxes, fontsize=9,
           bbox=dict(fc="white", ec="0.6", boxstyle="round,pad=0.3"))
ax[1].set_ylim(0, 1.05); ax[1].set_xlim(0, 2.0)
# (c) NPV vs capacity by export rate
for x, c in [(0.0, "#d1495b"), (1.0, "#edae49"), (2.2, "#00798c")]:
    s = D[np.isclose(D.exp_thb, x) & (D.p_kwp <= 6000)]
    ax[2].plot(s.p_kwp / 1000, s.npv / 1e6, color=c, lw=1.6, label=f"Export {x:.1f} THB/kWh")
    i = s.npv.idxmax(); ax[2].plot(s.loc[i, "p_kwp"] / 1000, s.loc[i, "npv"] / 1e6, "o", color=c, ms=6)
ax[2].axhline(0, color="0.5", lw=0.8)
ax[2].set_xlabel("PV capacity (MWp)"); ax[2].set_ylabel("25-year NPV, PV + biogas (M USD)")
ax[2].legend(fontsize=7.5, frameon=False, loc="lower left"); ax[2].set_xlim(0, 6)
for a, l in zip(ax, ["(a)", "(b)", "(c)"]):
    a.set_title(l, fontsize=10, loc="center")
    a.spines[["top", "right"]].set_visible(False)
fig.tight_layout()
fig.savefig("figures/graphical_abstract.png", dpi=300)
fig.savefig("figures/graphical_abstract.tif", dpi=300, pil_kwargs={"compression": "tiff_lzw"})
print("written")
